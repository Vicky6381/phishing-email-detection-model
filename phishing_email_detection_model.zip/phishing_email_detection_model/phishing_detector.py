import re
from pathlib import Path
import joblib
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, ConfusionMatrixDisplay
from sklearn.model_selection import train_test_split
from sklearn.pipeline import FeatureUnion, FunctionTransformer, Pipeline

DATA = Path("emails.csv")
MODEL = Path("phishing_email_model.joblib")

DEMO = [
("Urgent: Your account will be suspended. Verify your password now at http://secure-login.example/verify", "Phishing"),
("Congratulations! You won a prize. Click http://claim-prize.example now", "Phishing"),
("Your bank account needs immediate verification. Login to avoid closure http://bank-check.example", "Phishing"),
("Invoice attached. Please confirm your payment details using http://invoice-check.example", "Phishing"),
("Security alert: unusual login detected. Confirm your account immediately", "Phishing"),
("Final warning: update your account today or access will be disabled", "Phishing"),
("Dear customer, your mailbox is full. Verify your credentials to restore access", "Phishing"),
("You have been selected for a reward. Send your information to claim it", "Phishing"),
("Can you review the project report before tomorrow's meeting?", "Safe"),
("Hi team, the meeting is scheduled for 10 AM on Monday.", "Safe"),
("Please find the monthly sales report attached for your review.", "Safe"),
("Your order has shipped and is expected to arrive on Friday.", "Safe"),
("Thanks for your application. We will contact you after the interview.", "Safe"),
("Reminder: your electricity bill is due next week.", "Safe"),
("The maintenance team will visit the office at 2 PM tomorrow.", "Safe"),
("Please submit the assignment through the university portal before the deadline.", "Safe"),
("Your appointment is confirmed for Wednesday at 11 AM.", "Safe"),
("The database backup completed successfully last night.", "Safe"),
]

def create_dataset():
    if not DATA.exists():
        pd.DataFrame(DEMO, columns=["email", "label"]).to_csv(DATA, index=False)
        print("Created demo dataset:", DATA)

def url_features(values):
    return [[len(re.findall(r"https?://|www\\.", str(v), re.I))] for v in values]

def suspicious_features(values):
    words = re.compile(r"urgent|verify|password|suspend|winner|prize|login|confirm|credential|click", re.I)
    return [[len(words.findall(str(v)))] for v in values]

def train():
    create_dataset()
    df = pd.read_csv(DATA).dropna(subset=["email", "label"])
    df["label"] = df["label"].str.title()
    X_train, X_test, y_train, y_test = train_test_split(df.email, df.label, test_size=.25, random_state=42, stratify=df.label)

    features = FeatureUnion([
        ("tfidf", TfidfVectorizer(lowercase=True, ngram_range=(1, 2))),
        ("urls", Pipeline([("f", FunctionTransformer(url_features, validate=False))])),
        ("keywords", Pipeline([("f", FunctionTransformer(suspicious_features, validate=False))])),
    ])
    model = Pipeline([("features", features), ("classifier", LogisticRegression(max_iter=2000, class_weight="balanced"))])
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    acc = accuracy_score(y_test, pred)

    print("\n=== PHISHING EMAIL DETECTION MODEL ===")
    print(f"Accuracy: {acc:.2%}\n")
    print(classification_report(y_test, pred, zero_division=0))

    labels = ["Phishing", "Safe"]
    cm = confusion_matrix(y_test, pred, labels=labels)
    ConfusionMatrixDisplay(cm, display_labels=labels).plot()
    plt.title("Phishing Email Detection - Confusion Matrix")
    plt.tight_layout()
    plt.savefig("confusion_matrix.png", dpi=160)
    plt.close()
    joblib.dump(model, MODEL)
    print("Model saved to:", MODEL)
    return model

def predict(model, text):
    label = model.predict([text])[0]
    confidence = max(model.predict_proba([text])[0])
    return label, confidence

if __name__ == "__main__":
    model = train()
    print("\nEnter an email for prediction. Blank input exits.")
    while True:
        text = input("\nEmail: ").strip()
        if not text:
            break
        label, confidence = predict(model, text)
        print("Prediction:", label)
        print(f"Confidence: {confidence:.2%}")
