# Phishing Email Detection Model

Educational machine-learning mini project using Scikit-learn to classify emails as **Phishing** or **Safe**.

## Features
- TF-IDF text feature extraction
- URL and suspicious-keyword features
- Logistic Regression classifier
- Accuracy, precision, recall and F1-score
- Confusion matrix image
- Interactive terminal prediction
- Saves trained model

## Run
```bash
pip install -r requirements.txt
python phishing_detector.py
```

The project creates a small demonstration dataset automatically if `emails.csv` is missing.

> Use only for educational/defensive purposes. Do not use this model as the sole security control for real email filtering.
